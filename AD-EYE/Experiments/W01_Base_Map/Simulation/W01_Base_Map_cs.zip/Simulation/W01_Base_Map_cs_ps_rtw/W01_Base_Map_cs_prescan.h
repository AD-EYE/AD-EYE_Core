void W01_Base_Map_cs_prescan_parameters(RT_MODEL_W01_Base_Map_cs_T *const
  W01_Base_Map_cs_M);
