/*
 * Experiment_cs_capi.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Experiment_cs".
 *
 * Model version              : 1.76
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Sat Dec 12 17:01:36 2020
 *
 * Target selection: ps.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Experiment_cs_capi_h
#define RTW_HEADER_Experiment_cs_capi_h
#include "Experiment_cs.h"

extern void Experiment_cs_InitializeDataMapInfo(void);

#endif                                 /* RTW_HEADER_Experiment_cs_capi_h */

/* EOF: Experiment_cs_capi.h */
