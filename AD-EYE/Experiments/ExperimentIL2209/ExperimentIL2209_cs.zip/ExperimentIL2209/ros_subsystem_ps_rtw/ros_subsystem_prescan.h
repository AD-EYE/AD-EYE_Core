void ros_subsystem_prescan_parameters(RT_MODEL_ros_subsystem_T *const
  ros_subsystem_M);
