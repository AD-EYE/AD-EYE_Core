void Emulate_Prescan_2019a_prescan_parameters(RT_MODEL_Emulate_Prescan_2019_T *
  const Emulate_Prescan_2019a_M);
